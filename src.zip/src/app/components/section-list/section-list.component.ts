import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

import _sections from '../../data/section/james.json';
import { Section } from '../../model/section';

@Component({
  selector: 'app-section-list',
  templateUrl: './section-list.component.html',
  styleUrls: ['./section-list.component.css']
})
export class SectionListComponent implements OnInit {

  sections: Section.RootObject[] = [];

  constructor(private router: Router) {
    for (const section of _sections) {
      this.sections.push(section);
    }
  }

  userClickedOnSection(section_id): void {
    this.router.navigateByUrl('/sections/' + section_id);
  }

  ngOnInit() {
  }

}
