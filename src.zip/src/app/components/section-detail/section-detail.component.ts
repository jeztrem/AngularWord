import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, ParamMap } from '@angular/router';
import { Location } from '@angular/common';

import { Section } from '../../model/section';
import { Note } from '../../model/note';
import { VerseDetail, Reference } from '../../model/versedetail';
import { VerseService } from 'src/app/services/verse.service';

import sections from '../../data/section/james.json';
import notes from '../../data/note/james.json';
import book from '../../data/bible/james.json';
import references from '../../data/reference/james.json';

@Component({
  selector: 'app-section-detail',
  templateUrl: './section-detail.component.html',
  styleUrls: ['./section-detail.component.scss']
})
export class SectionDetailComponent implements OnInit {

  // These seem to get reset every time this component is accessed.
  // No need to clear arrays.?

  section: Section.RootObject;
  versedetails: VerseDetail[] = [];

  constructor(
    private route: ActivatedRoute,
    private location: Location,
    private verse_service: VerseService) {
  }

  ngOnInit() {

    this.route.paramMap.subscribe((params: ParamMap) => {
      this.section = this.findSectionById(parseInt(params.get('section_id'), 10));
    });

    this.loadSection();

  }

  findSectionById(_id: number): Section.RootObject {
    for (const section of sections) {
      if (section.id === _id) {
        return section;
      }
    }
    return null;
  }

  loadSection(): void {

    // Construct the versedetail.
    // The verses in the Section are the keys used in the construction.
    for (const rootObject of book) {
      if (rootObject.chapter === this.section.chapter) {
        // Now I have the correct chapter.
        for (let index = this.section.start; index <= this.section.finish; index++) {
          for (const verse of rootObject.verse) {
            if (index === verse.index) {
              // Now I have the correct verse.
              const versenote = this.loadVerseNotes(this.section.chapter, index);
              const versereferences = this.loadReferences(this.section.chapter, index);

              const versedetail =
                new VerseDetail(index,
                  verse.text,
                  versenote.remarks,
                  versenote.applications,
                  versereferences);

              this.versedetails.push(versedetail);
            }
          }
        }
      }
    }
  }

  loadVerseNotes(_chapter: number, _index: number): Note.IVerseNote {
    for (const rootObject of notes) {
      if (rootObject.chapter === _chapter) {
        for (const versenote of rootObject.versenotes) {
          if (versenote.index === _index) {
            // Now I have the correct verse
            return versenote;
          }
        }
      }
    }
  }

  loadReferences(_chapter: number, _index: number): Reference[] {
    // Find the reference verses (book,chapter,start,finish,text) from the chapter:index.
    // The text of the reference verses are obtained from the VerseService.
    const versereferences: Reference[] = [];
    for (const rootObject of references) {
      if (rootObject.chapter === _chapter) {
        for (const verse of rootObject.verse) {
          if (verse.index === _index) {
            // Now I have the correct verse.
            for (const versereference of verse.references) {
              versereferences.push(
                this.loadTextFromVerseService(
                  versereference.book,
                  versereference.chapter,
                  versereference.start,
                  versereference.finish));
            }
          }
        }
      }
    }
    return versereferences;
  }

  loadTextFromVerseService(_book: string, _chapter: number, _start: number, _finish: number): Reference {
    const text = this.verse_service.getVerseText(_book, _chapter, _start, _finish);
    const reference: Reference = new Reference(_book, _chapter, _start, _finish, text);
    return reference;
  }
}
