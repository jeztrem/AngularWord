export namespace Section {

    export class RootObject {

        constructor(
            public id: number,
            public header: string,
            public book: string,
            public chapter: number,
            public start: number,
            public finish: number,
            public introduction: string[],
            public summary: string[]) { }

        public static sectionFromJSON(obj: any): RootObject {
            return new RootObject(obj.id, obj.header, obj.book, obj.chapter, obj.start, obj.finish, obj.introduction, obj.summary);
        }
    }
}
