import { NgModule } from '@angular/core';

import {
    MatButtonModule,
    MatListModule,
    MatCardModule,
    MatGridListModule,
    MatExpansionModule,
    MatDividerModule
} from '@angular/material';

@NgModule({
    imports: [MatButtonModule, MatListModule, MatCardModule, MatGridListModule, MatExpansionModule, MatDividerModule],
    exports: [MatButtonModule, MatListModule, MatCardModule, MatGridListModule, MatExpansionModule, MatDividerModule]
})

export class MaterialModule { }
