import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MaterialModule } from './material.module';
import { FlexLayoutModule } from '@angular/flex-layout';

import { SectionOverviewComponent } from './components/section-overview/section-overview.component';
import { SectionListComponent } from './components/section-list/section-list.component';
import { SectionDetailComponent } from './components/section-detail/section-detail.component';

@NgModule({
  declarations: [
    AppComponent,
    SectionOverviewComponent,
    SectionListComponent,
    SectionDetailComponent
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    MaterialModule,
    AppRoutingModule,
    FlexLayoutModule,
    RouterModule.forRoot([
      {
        path: 'sections',
        component: SectionListComponent
      },
      {
        path: 'sections/:section_id',
        component: SectionDetailComponent
      },
      {
        path: '',
        redirectTo: '/sections',
        pathMatch: 'full'
      }])
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
