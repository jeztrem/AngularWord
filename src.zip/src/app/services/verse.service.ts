import { Injectable } from '@angular/core';

import { Book } from '../model/book';

import corinthans1 from '../data/bible/corinthians.1.json';
import corinthians2 from '../data/bible/corinthians.2.json';
import deuteronomy from '../data/bible/deuteronomy.json';
import ephesians from '../data/bible/ephesians.json';
import hebrews from '../data/bible/hebrews.json';
import isaiah from '../data/bible/isaiah.json';
import james from '../data/bible/james.json';
import john1 from '../data/bible/john.1.json';
import luke from '../data/bible/luke.json';
import mark from '../data/bible/mark.json';
import matthew from '../data/bible/matthew.json';
import peter1 from '../data/bible/peter.1.json';
import proverbs from '../data/bible/proverbs.json';
import psalms from '../data/bible/psalms.json';
import romans from '../data/bible/romans.json';
import timothy1 from '../data/bible/timothy.1.json';
import timothy2 from '../data/bible/timothy.2.json';

@Injectable({
  providedIn: 'root'
})

export class VerseService {
  /* This is a work around for '1 John' stored as 'John1' */
  /* The Key is what the user sees, the Value is what the app uses.*/
  bibleKeyValue = new Map<string, Book.RootObject[]>();

  constructor() {
    this.setChapterKeyValues();
  }

  setChapterKeyValues() {
    this.bibleKeyValue.set('Luke', luke);
    this.bibleKeyValue.set('1 Peter', peter1);
    this.bibleKeyValue.set('1 Corinthians', corinthans1);
    this.bibleKeyValue.set('2 Corinthians', corinthians2);
    this.bibleKeyValue.set('Deuteronomy', deuteronomy);
    this.bibleKeyValue.set('Ephesians', ephesians);
    this.bibleKeyValue.set('Hebrews', hebrews);
    this.bibleKeyValue.set('Isaiah', isaiah);
    this.bibleKeyValue.set('James', james);
    this.bibleKeyValue.set('1 John', john1);
    this.bibleKeyValue.set('Mark', mark);
    this.bibleKeyValue.set('Matthew', matthew);
    this.bibleKeyValue.set('Proverbs', proverbs);
    this.bibleKeyValue.set('Psalms', psalms);
    this.bibleKeyValue.set('Romans', romans);
    this.bibleKeyValue.set('1 Timothy', timothy1);
    this.bibleKeyValue.set('2 Timothy', timothy2);
  }

  getVerseText(_book: string, chapter: number, _start: number, _finish: number): string {

    let versetext = ' ';
    if (this.bibleKeyValue.has(_book)) {
      const bibleBookValue: Book.RootObject[] = this.bibleKeyValue.get(_book);
      for (const rootObject of bibleBookValue) {
        if (rootObject.chapter === chapter) {
          // I have the right chapter.
          for (let index = _start; index <= _finish; index++) {
            for (const verse of rootObject.verse) {
              if (verse.index === index) {
                versetext += verse.text + ' ';
              }
            }
          }
        }
      }

    } else {
      versetext = 'Book not Found';
    }
    return versetext;
  }
}
